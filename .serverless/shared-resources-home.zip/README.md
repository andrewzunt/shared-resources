# shared-resources
An application for Sascha to manage shared resources within his community
